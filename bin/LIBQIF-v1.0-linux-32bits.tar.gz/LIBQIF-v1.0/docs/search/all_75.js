var searchData=
[
  ['usando_5farmadillo_2ecpp',['usando_armadillo.cpp',['../usando__armadillo_8cpp.html',1,'']]]
];
