var searchData=
[
  ['jd_2ec',['jd.c',['../jd_8c.html',1,'']]],
  ['jd_2eh',['jd.h',['../jd_8h.html',1,'']]]
];
