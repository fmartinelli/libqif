var searchData=
[
  ['basbrk_5fstruct',['BASBRK_struct',['../struct_b_a_s_b_r_k__struct.html',1,'']]],
  ['bool_5fconstant',['bool_constant',['../structtesting_1_1internal_1_1bool__constant.html',1,'testing::internal']]],
  ['bool_5fconstant_3c_20implicitlyconvertible_3c_20const_20t_20_2a_2c_20const_20_3a_3aprotocolmessage_20_2a_20_3e_3a_3avalue_7c_7cimplicitlyconvertible_3c_20const_20t_20_2a_2c_20const_20_3a_3aproto2_3a_3amessage_20_2a_20_3e_3a_3avalue_20_3e',['bool_constant&lt; ImplicitlyConvertible&lt; const T *, const ::ProtocolMessage * &gt;::value||ImplicitlyConvertible&lt; const T *, const ::proto2::Message * &gt;::value &gt;',['../structtesting_1_1internal_1_1bool__constant.html',1,'testing::internal']]],
  ['byref',['ByRef',['../structstd_1_1tr1_1_1gtest__internal_1_1_by_ref.html',1,'std::tr1::gtest_internal']]],
  ['byref_3c_20t_20_26_20_3e',['ByRef&lt; T &amp; &gt;',['../structstd_1_1tr1_1_1gtest__internal_1_1_by_ref_3_01_t_01_6_01_4.html',1,'std::tr1::gtest_internal']]]
];
