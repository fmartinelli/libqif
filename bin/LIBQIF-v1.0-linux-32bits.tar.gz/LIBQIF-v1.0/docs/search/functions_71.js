var searchData=
[
  ['qzcel',['qzcel',['../blocks_8h.html#ac0b4e4d0b739a7b6f4e4a43aafa67ec5',1,'blocks.h']]],
  ['qzflr',['qzflr',['../blocks_8h.html#a4588f63c40a0fa252408dbcc35bd863e',1,'blocks.h']]],
  ['qzrnd',['qzrnd',['../blocks_8h.html#a8b46e956be3f1c20cad95ba3582345ea',1,'blocks.h']]],
  ['qztrn',['qztrn',['../blocks_8h.html#ad2eaf794c53bf309563afe404c4800fb',1,'blocks.h']]]
];
