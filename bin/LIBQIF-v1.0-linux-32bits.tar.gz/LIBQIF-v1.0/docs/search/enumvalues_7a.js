var searchData=
[
  ['zerocrossing',['ZeroCrossing',['../scicos__block4_8h.html#a92c753a9d6d0a593024ead96415d43dda0631dc916df10690c7f91abc5b0cbbfd',1,'scicos_block4.h']]]
];
