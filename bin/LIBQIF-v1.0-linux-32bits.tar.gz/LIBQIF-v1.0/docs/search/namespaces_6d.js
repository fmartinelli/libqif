var searchData=
[
  ['my_5fnamespace',['my_namespace',['../namespacemy__namespace.html',1,'']]],
  ['testing',['testing',['../namespacemy__namespace_1_1testing.html',1,'my_namespace']]]
];
