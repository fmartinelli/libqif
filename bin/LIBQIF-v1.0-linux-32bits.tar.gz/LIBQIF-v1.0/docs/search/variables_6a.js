var searchData=
[
  ['jcur',['jcur',['../struct_l_s0001__struct.html#ab83fe8285cb11dc43f8e76418ba4ffb5',1,'LS0001_struct']]],
  ['jroot',['jroot',['../structscicos__block.html#a138c8c69f79f351b7d50fe6dbb8f25b0',1,'scicos_block']]],
  ['jstart',['jstart',['../struct_l_s0001__struct.html#a15049ec23240fdd1262d2c0ec796a73e',1,'LS0001_struct']]],
  ['jtyp',['jtyp',['../struct_l_s_a001__struct.html#a222b456f8ab65e7073014d0cb983e019',1,'LSA001_struct']]]
];
