#!/bin/sh
# creating the libraries needeed by libqif
echo Installing armadillo
cd thirdparty/armadillo-3.920.1/
cmake .
make
sudo make install
cd ..
cd ..
