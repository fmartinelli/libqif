var searchData=
[
  ['linked_5fptr',['linked_ptr',['../classtesting_1_1internal_1_1linked__ptr.html#a7763f286ca03a7f7363a033d996c8c1c',1,'testing::internal::linked_ptr']]]
];
