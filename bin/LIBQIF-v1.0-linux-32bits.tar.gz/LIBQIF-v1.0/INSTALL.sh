#!/bin/sh
# creating the libraries needeed by libqif
echo Installing armadillo
cd thirdparty/armadillo-3.920.1/
./configure
cmake .
make
sudo make install
cd ..
cd ..
echo Installing glpk
cd thirdparty/glpk-4.52/
./configure
make
sudo make install
cd ..
cd ..
