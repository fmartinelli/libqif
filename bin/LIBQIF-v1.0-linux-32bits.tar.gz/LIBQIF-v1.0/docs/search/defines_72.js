var searchData=
[
  ['rad2deg',['RAD2DEG',['../core__math_8h.html#af93ab8e29004f71549e1cd50278c5473',1,'core_math.h']]],
  ['readmatrix',['ReadMatrix',['../stack-c_8h.html#a39c6f9ec8dd23a248645b7c8968de971',1,'stack-c.h']]],
  ['readstring',['ReadString',['../stack-c_8h.html#a08f518f243b5e52d1b6700916c4df0a9',1,'stack-c.h']]],
  ['real',['REAL',['../mex_8h.html#a4b654506f18b8bfd61ad2a29a7e38c25',1,'mex.h']]],
  ['real32_5ft',['REAL32_T',['../mex_8h.html#a8e479c5f5f9c2fc7fe4d72444d6408c3',1,'mex.h']]],
  ['realloc',['REALLOC',['../sci__mem__alloc_8h.html#a2e501a3b49991d5e526b5c52c1522df4',1,'sci_mem_alloc.h']]],
  ['retsigtype',['RETSIGTYPE',['../machine_8h.html#adbe5dcee9c146b338794974137c55e70',1,'machine.h']]],
  ['returnarguments',['ReturnArguments',['../api__common_8h.html#a566d499ff8a12dcb3e4fec7a990811d1',1,'api_common.h']]],
  ['rhs',['Rhs',['../api__common_8h.html#a55cf69050901bcd92561f6352a29ba45',1,'Rhs():&#160;api_common.h'],['../stack-c_8h.html#a55cf69050901bcd92561f6352a29ba45',1,'Rhs():&#160;stack-c.h']]],
  ['round',['round',['../core__math_8h.html#a52b76bc2991db4c888d07d1e016b8939',1,'core_math.h']]],
  ['row_5fletter',['ROW_LETTER',['../stack3_8h.html#af28a2ce36ee0e3a7f09ea8ac1821114e',1,'stack3.h']]]
];
