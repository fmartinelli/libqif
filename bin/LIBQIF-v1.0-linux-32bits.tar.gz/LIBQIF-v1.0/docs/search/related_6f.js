var searchData=
[
  ['op_5fhtrans',['op_htrans',['../class_mat.html#a217a7689e6edc0afb11683593c40e2db',1,'Mat']]],
  ['op_5freshape',['op_reshape',['../class_cube.html#a2a452cbc335fe36ab70260e5c7c3b8b0',1,'Cube']]],
  ['op_5fresize',['op_resize',['../class_cube.html#a07336aa497ae6da9bf498f1ba5a1b991',1,'Cube::op_resize()'],['../class_mat.html#a07336aa497ae6da9bf498f1ba5a1b991',1,'Mat::op_resize()']]],
  ['op_5fstrans',['op_strans',['../class_mat.html#acb1af2e99e0c1b5cc73c6ba0b56de3ba',1,'Mat']]]
];
