var searchData=
[
  ['addglobaltestenvironment',['AddGlobalTestEnvironment',['../classtesting_1_1_unit_test.html#a5ec26e4c31220ff8e769cc09689a4d6d',1,'testing::UnitTest']]]
];
