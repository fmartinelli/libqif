var searchData=
[
  ['unwrap',['Unwrap',['../group__unwrap.html',1,'']]],
  ['unwrap_5fcube',['Unwrap_cube',['../group__unwrap__cube.html',1,'']]],
  ['unwrap_5fspmat',['Unwrap_spmat',['../group__unwrap__spmat.html',1,'']]],
  ['upgrade_5fval',['Upgrade_val',['../group__upgrade__val.html',1,'']]]
];
