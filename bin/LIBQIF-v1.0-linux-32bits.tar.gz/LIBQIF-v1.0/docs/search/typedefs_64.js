var searchData=
[
  ['doubletype',['DoubleType',['../types_8h.html#a5f642903648a5cbec7a6d8326bc2eed6',1,'types.h']]]
];
