var searchData=
[
  ['zeros',['zeros',['../class_gain.html#ab05a634a88ffa51e2f5ed1d9214b52cb',1,'Gain']]]
];
