var searchData=
[
  ['join',['join',['../classtesting_1_1internal_1_1linked__ptr__internal.html#acd5a341459f7e81b10b4112d8c764e2a',1,'testing::internal::linked_ptr_internal']]],
  ['join_5fnew',['join_new',['../classtesting_1_1internal_1_1linked__ptr__internal.html#a742af1f65df2d5e2b7198a1b74264a83',1,'testing::internal::linked_ptr_internal']]]
];
