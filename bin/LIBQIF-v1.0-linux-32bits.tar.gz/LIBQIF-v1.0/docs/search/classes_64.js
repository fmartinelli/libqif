var searchData=
[
  ['dbcos_5fstruct',['DBCOS_struct',['../struct_d_b_c_o_s__struct.html',1,'']]],
  ['dbg_5fstruct',['DBG_struct',['../struct_d_b_g__struct.html',1,'']]],
  ['doublecomplex',['doublecomplex',['../structdoublecomplex.html',1,'']]]
];
