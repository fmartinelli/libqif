var searchData=
[
  ['stringtype',['StringType',['../types_8h.html#ae96f7e0a0a27a61d630bd0e90e5fb7be',1,'types.h']]]
];
