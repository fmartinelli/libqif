var searchData=
[
  ['odeex',['odeex',['../my__ode_8c.html#aa61a17fd6e1fab058862d40667353004',1,'my_ode.c']]],
  ['outputs_5fnumber',['outputs_number',['../class_channel.html#ac56a9a5072dfaad157203eec5af1edef',1,'Channel']]]
];
