var searchData=
[
  ['x',['x',['../struct_base.html#a36c8c0802192422ed35523c35791be54',1,'Base::x()'],['../class_private_code.html#a498ca4a1f33008f20569823125222d55',1,'PrivateCode::x()']]],
  ['xdlclose',['xdlclose',['../env_8h.html#aafcc7dca3bdd2f4c3f1d5bce7a7eccbd',1,'xdlclose(void *h):&#160;glpenv08.c'],['../glpenv08_8c.html#aafcc7dca3bdd2f4c3f1d5bce7a7eccbd',1,'xdlclose(void *h):&#160;glpenv08.c']]],
  ['xdlopen',['xdlopen',['../env_8h.html#af3f3dbca2a35846845be193daab2d43b',1,'xdlopen(const char *module):&#160;glpenv08.c'],['../glpenv08_8c.html#af3f3dbca2a35846845be193daab2d43b',1,'xdlopen(const char *module):&#160;glpenv08.c']]],
  ['xdlsym',['xdlsym',['../env_8h.html#a204ed859457309d12be8177beb416f09',1,'xdlsym(void *h, const char *symbol):&#160;glpenv08.c'],['../glpenv08_8c.html#a204ed859457309d12be8177beb416f09',1,'xdlsym(void *h, const char *symbol):&#160;glpenv08.c']]],
  ['xerrmsg',['xerrmsg',['../env2_8h.html#a9d250076750778d63d1907a047dafc0b',1,'xerrmsg(void):&#160;glpenv07.c'],['../glpenv07_8c.html#a9d250076750778d63d1907a047dafc0b',1,'xerrmsg(void):&#160;glpenv07.c']]],
  ['xfclose',['xfclose',['../env2_8h.html#a71cb672ecf39aea78b2db28f33d70ac3',1,'xfclose(XFILE *file):&#160;glpenv07.c'],['../glpenv07_8c.html#a09b1ab349d5c68428ecc9f549d843cac',1,'xfclose(XFILE *fp):&#160;glpenv07.c']]],
  ['xfeof',['xfeof',['../env2_8h.html#a553df4f1c47b212300f58ae3e2db71e6',1,'xfeof(XFILE *file):&#160;glpenv07.c'],['../glpenv07_8c.html#a38dedf48b8c0522107763849589622aa',1,'xfeof(XFILE *fp):&#160;glpenv07.c']]],
  ['xferror',['xferror',['../env2_8h.html#a944d65509015580bd7a8f42bd3468e7b',1,'xferror(XFILE *file):&#160;glpenv07.c'],['../glpenv07_8c.html#aae9943cda9997c18a0762f742bdd2483',1,'xferror(XFILE *fp):&#160;glpenv07.c']]],
  ['xfflush',['xfflush',['../env2_8h.html#a67e973de8cb55962854b395e12a942c8',1,'xfflush(XFILE *fp):&#160;glpenv07.c'],['../glpenv07_8c.html#a67e973de8cb55962854b395e12a942c8',1,'xfflush(XFILE *fp):&#160;glpenv07.c']]],
  ['xfgetc',['xfgetc',['../env2_8h.html#ac81fa18e535f897797fc81eb461f1c12',1,'xfgetc(XFILE *file):&#160;glpenv07.c'],['../glpenv07_8c.html#a752f008a6c6ea4922d26704c8f0409fc',1,'xfgetc(XFILE *fp):&#160;glpenv07.c']]],
  ['xfopen',['xfopen',['../env2_8h.html#a1624bdfe434e715c7a2d7f71384895f0',1,'xfopen(const char *fname, const char *mode):&#160;glpenv07.c'],['../glpenv07_8c.html#a1624bdfe434e715c7a2d7f71384895f0',1,'xfopen(const char *fname, const char *mode):&#160;glpenv07.c']]],
  ['xfprintf',['xfprintf',['../env2_8h.html#aea4abd3eab7066fbfd4fb12301bf6e6a',1,'xfprintf(XFILE *file, const char *fmt,...):&#160;glpenv07.c'],['../glpenv07_8c.html#aea4abd3eab7066fbfd4fb12301bf6e6a',1,'xfprintf(XFILE *file, const char *fmt,...):&#160;glpenv07.c']]],
  ['xfputc',['xfputc',['../env2_8h.html#a80adf49006dcef8664d55e054ce77761',1,'xfputc(int c, XFILE *file):&#160;glpenv07.c'],['../glpenv07_8c.html#a700296a32050ce847978c1e3f973ab33',1,'xfputc(int c, XFILE *fp):&#160;glpenv07.c']]],
  ['xmlunittestresultprinter',['XmlUnitTestResultPrinter',['../classtesting_1_1internal_1_1_xml_unit_test_result_printer.html#afdaf88e6764c18ce0dcc3733d7a06e31',1,'testing::internal::XmlUnitTestResultPrinter::XmlUnitTestResultPrinter(const char *output_file)'],['../classtesting_1_1internal_1_1_xml_unit_test_result_printer.html#afdaf88e6764c18ce0dcc3733d7a06e31',1,'testing::internal::XmlUnitTestResultPrinter::XmlUnitTestResultPrinter(const char *output_file)']]],
  ['xvec_5fhtrans',['xvec_htrans',['../group__xvec__htrans.html#ga8456e4f2cddbca48c72e6fd11168f7d9',1,'xvec_htrans']]]
];
