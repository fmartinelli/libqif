var searchData=
[
  ['new_5fid_5fchannel',['new_id_channel',['../class_channel.html#af1b2dcdadaaf756b1614a7f357a19669',1,'Channel']]],
  ['new_5fid_5ffunction',['new_id_function',['../class_gain.html#acccc33256bf4644513558d87ada97538',1,'Gain']]]
];
