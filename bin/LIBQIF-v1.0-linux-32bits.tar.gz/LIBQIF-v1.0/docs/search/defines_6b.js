var searchData=
[
  ['kellerman',['kellerman',['../keller_8h.html#a6597d2620ea14a478c01e548c0bdc420',1,'keller.h']]],
  ['kill_5fnon_5fprincipal_5fcol',['KILL_NON_PRINCIPAL_COL',['../colamd_8c.html#a0458a358e752473d86e6f21a56b44a26',1,'colamd.c']]],
  ['kill_5fprincipal_5fcol',['KILL_PRINCIPAL_COL',['../colamd_8c.html#a7882929a7898e09a3de9e7676ae1aa29',1,'colamd.c']]],
  ['kill_5frow',['KILL_ROW',['../colamd_8c.html#adde21248544152df48ab70b6da1b38b5',1,'colamd.c']]],
  ['ktl',['ktl',['../glpnet03_8c.html#a83641e04b917392a209ddea96626b596',1,'glpnet03.c']]]
];
