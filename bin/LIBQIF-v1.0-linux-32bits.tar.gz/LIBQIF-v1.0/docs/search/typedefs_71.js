var searchData=
[
  ['quasi_5funwrap_5fextra',['quasi_unwrap_extra',['../structquasi__unwrap.html#ac22f9b997b20b9a72870c11bb050d74d',1,'quasi_unwrap']]]
];
