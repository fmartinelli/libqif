var searchData=
[
  ['inputs_5fnumber',['inputs_number',['../class_channel.html#a65d6e59622b1efe2816dab34373112df',1,'Channel::inputs_number()'],['../class_gain.html#a6365ea3ed9140bd347beb3f81c75d33a',1,'Gain::inputs_number()']]],
  ['inv',['inv',['../class_c_matrix.html#a7d9e958bfa5d04a5ca712efaa5b0db8c',1,'CMatrix']]],
  ['is_5fan_5fedge',['is_an_edge',['../class_graph.html#ac8c7d95482107d3ab01fd31f130d8877',1,'Graph']]],
  ['is_5fdifferential_5fprivate',['is_differential_private',['../class_mechanism.html#a9cc643e3a27a5b10bbe677e3b8e84aaf',1,'Mechanism']]],
  ['is_5fsymmetric',['is_symmetric',['../class_channel.html#a3b656fcb31a522141b0a9c3e1d4f0fac',1,'Channel::is_symmetric()'],['../class_gain.html#a14c88576f3ac55ecdd0745ca34a075b5',1,'Gain::is_symmetric()']]]
];
