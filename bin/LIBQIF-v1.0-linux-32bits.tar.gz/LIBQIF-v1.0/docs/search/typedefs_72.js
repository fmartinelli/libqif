var searchData=
[
  ['real32_5ft',['real32_T',['../mex_8h.html#a53a13344ce9d73ef084810558b94d919',1,'mex.h']]],
  ['rhs_5fopts',['rhs_opts',['../stack-c_8h.html#a23c195ba30d6c225d8aed169db07c850',1,'stack-c.h']]]
];
