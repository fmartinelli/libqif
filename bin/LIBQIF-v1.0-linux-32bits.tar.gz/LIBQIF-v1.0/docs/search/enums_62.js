var searchData=
[
  ['bool',['BOOL',['../_b_o_o_l_8h.html#a3e5b8192e7d9ffaf3542f1210aec18dd',1,'BOOL.h']]]
];
