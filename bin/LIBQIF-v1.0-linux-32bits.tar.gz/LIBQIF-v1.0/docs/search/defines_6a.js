var searchData=
[
  ['jdate',['jdate',['../jd_8h.html#a126fa9998aaa950c5c48b5b36b45a9ca',1,'jd.h']]],
  ['jday',['jday',['../jd_8h.html#a6e754859b637b0a929a74ff4683f6d44',1,'jd.h']]],
  ['jran',['jran',['../glpnet03_8c.html#a2f81a157d0f08a6c4846954373c4838b',1,'glpnet03.c']]]
];
