var searchData=
[
  ['varptr',['VarPtr',['../stack-c_8h.html#a189081b8db3be8fc48a0152b631875f0',1,'stack-c.h']]],
  ['vartype',['VarType',['../stack-c_8h.html#ab88ec1bd797eb199a5f8459b61cde375',1,'stack-c.h']]],
  ['version',['VERSION',['../machine_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'machine.h']]],
  ['void_5fobject',['VOID_OBJECT',['../_external_objects_8h.html#ac8918453dbe78bb9817757f4f6d46497',1,'ExternalObjects.h']]],
  ['vsiz',['vsiz',['../stack-def_8h.html#a8d23c66f31de9f30f52fea1611a94ca5',1,'stack-def.h']]]
];
