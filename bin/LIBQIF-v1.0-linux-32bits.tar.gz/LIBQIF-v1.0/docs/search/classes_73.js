var searchData=
[
  ['scierror',['SciError',['../class_sci_error.html',1,'']]],
  ['shannon',['Shannon',['../class_shannon.html',1,'']]]
];
