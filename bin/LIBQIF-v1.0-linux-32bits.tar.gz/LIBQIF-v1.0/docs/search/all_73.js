var searchData=
[
  ['sci',['SCI',['../myprog_8c.html#a55f3dba6dddf56811acce556c06ba2df',1,'myprog.c']]],
  ['scierror',['SciError',['../class_sci_error.html',1,'']]],
  ['scijob',['scijob',['../class_c_matrix.html#a73e20448a9ac7b6b53c50b6922302c8c',1,'CMatrix']]],
  ['send_5fscilab_5fjob',['send_scilab_job',['../ccmatrix1_8cpp.html#a10cf6670bad71a0a38edcfd5c66c1f59',1,'ccmatrix1.cpp']]],
  ['sendscilabjob',['SendScilabJob',['../ccmatrix1_8cc.html#a6195e58190c5dc896cb6ede6bc1afb8c',1,'SendScilabJob(char *):&#160;ccmatrix1.cc'],['../myprog_8c.html#ab3e4096e18913b8b509e467f84b7f574',1,'SendScilabJob(char *job):&#160;myprog.c']]],
  ['shannon',['Shannon',['../class_shannon.html',1,'Shannon'],['../class_shannon.html#a934f4c34216cd61c286d9a2175171ef8',1,'Shannon::Shannon()']]],
  ['shannon_2ecpp',['Shannon.cpp',['../_shannon_8cpp.html',1,'']]],
  ['shannon_2eh',['Shannon.h',['../_shannon_8h.html',1,'']]],
  ['size',['size',['../class_prob.html#a1625295632fb501713c3ceca6b3c642d',1,'Prob']]],
  ['solve',['solve',['../class_linear_program.html#af58ee4754a81c9ed385b99ce7222c5dd',1,'LinearProgram::solve(StringType &amp;equality, StringType &amp;inequality, StringType &amp;objective)'],['../class_linear_program.html#a645975f2522120a0ff4ba3d8df1f2867',1,'LinearProgram::solve(MatrixType equality, MatrixType inequality, VectorType objective)'],['../class_linear_program.html#aed94955f60cb542c785dc176c375bdcc',1,'LinearProgram::solve(StringType &amp;equality, StringType &amp;inequality, StringType &amp;objective, StringType &amp;rows_constraints)'],['../class_linear_program.html#af4b53eac5b545d1031f0ec9511e1fbd9',1,'LinearProgram::solve(MatrixType equality, MatrixType inequality, VectorType objective, MatrixType rows_constraints)']]],
  ['startscilab',['StartScilab',['../myprog_8c.html#a48425dff551747f6fca753f7bfb454a2',1,'myprog.c']]],
  ['str',['str',['../class_channel.html#a15f642dc97fa0b92828eeaececd07a6c',1,'Channel::str()'],['../class_gain.html#a23bc367fcfeee2caf0d04c91a69ef510',1,'Gain::str()'],['../class_prob.html#a447c004033b76b1ef782f57f7f470ef2',1,'Prob::str()']]],
  ['stringtype',['StringType',['../types_8h.html#ae96f7e0a0a27a61d630bd0e90e5fb7be',1,'types.h']]]
];
