var searchData=
[
  ['bar',['bar',['../namespacebar.html',1,'']]]
];
