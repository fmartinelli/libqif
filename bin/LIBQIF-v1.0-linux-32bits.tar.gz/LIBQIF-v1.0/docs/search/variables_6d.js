var searchData=
[
  ['matrix',['matrix',['../class_channel.html#a2d99c5e0ef0927a5c3bce0cd3b933b10',1,'Channel::matrix()'],['../class_gain.html#a7cbd1ededb85d68fab0f04ea34ed3eac',1,'Gain::matrix()']]]
];
